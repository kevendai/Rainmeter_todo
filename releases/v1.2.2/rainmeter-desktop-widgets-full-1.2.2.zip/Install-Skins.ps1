﻿param(
    [string]$RainmeterRoot,
    [switch]$Activate,
    [int]$WaitForProcessId = 0
)

$ErrorActionPreference = 'Stop'
$packageRoot = $PSScriptRoot
$updater = Join-Path $packageRoot 'Updater\RainmeterDesktopWidgetsUpdater.ps1'
if (-not (Test-Path -LiteralPath $updater)) { throw 'Updater script not found in package.' }
& powershell -NoProfile -ExecutionPolicy Bypass -File $updater -Mode InstallPackage -PackageRoot $packageRoot -RainmeterRoot $RainmeterRoot -Activate:$Activate -WaitForProcessId $WaitForProcessId
