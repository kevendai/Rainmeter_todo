param(
    [string]$RainmeterRoot,
    [switch]$Activate,
    [int]$WaitForProcessId = 0
)

# Compatibility entry point of the legacy package. It carries no payload: the
# real work happens in Updater\RainmeterDesktopWidgetsUpdater.ps1, which
# downloads the canonical release package and installs it.
$ErrorActionPreference = 'Stop'
$updater = Join-Path $PSScriptRoot 'Updater\RainmeterDesktopWidgetsUpdater.ps1'
if (-not (Test-Path -LiteralPath $updater)) { throw 'Updater script not found in the compatibility package.' }
$forward = @('-NoProfile', '-ExecutionPolicy', 'Bypass', '-File', $updater, '-Mode', 'InstallPackage', '-PackageRoot', $PSScriptRoot)
if (-not [string]::IsNullOrWhiteSpace($RainmeterRoot)) { $forward += @('-RainmeterRoot', $RainmeterRoot) }
if ($Activate) { $forward += '-Activate' }
if ($WaitForProcessId -gt 0) { $forward += @('-WaitForProcessId', $WaitForProcessId) }
$process = Start-Process -FilePath 'powershell.exe' -ArgumentList $forward -Wait -PassThru
exit $process.ExitCode
