param(
    [string]$RainmeterRoot,
    [switch]$Activate,
    [int]$WaitForProcessId = 0
)

$ErrorActionPreference = 'Stop'
$packageRoot = $PSScriptRoot
$updater = Join-Path $packageRoot 'Updater\UpdaterHost.exe'
if (-not (Test-Path -LiteralPath $updater)) { throw 'UpdaterHost.exe not found in package.' }
$args = @('-Mode','InstallPackage','-PackageRoot',$packageRoot)
if (-not [string]::IsNullOrWhiteSpace($RainmeterRoot)) { $args += @('-RainmeterRoot',$RainmeterRoot) }
if ($Activate) { $args += '-Activate' }
$escaped = @($args | ForEach-Object { if ($_ -match '[\s"]') { '"' + ($_ -replace '"', '\"') + '"' } else { $_ } })
$process = Start-Process -FilePath $updater -ArgumentList $escaped -Wait -PassThru
exit $process.ExitCode
