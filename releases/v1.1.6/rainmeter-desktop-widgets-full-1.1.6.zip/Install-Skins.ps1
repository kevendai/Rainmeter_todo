﻿param(
    [string]$RainmeterRoot,
    [switch]$Activate,
    [int]$WaitForProcessId = 0
)

$ErrorActionPreference = 'Stop'
$packageRoot = $PSScriptRoot
$sourceSkins = Join-Path $packageRoot 'Skins'
if ([string]::IsNullOrWhiteSpace($RainmeterRoot)) {
    $RainmeterRoot = Read-Host 'Enter Rainmeter portable directory containing Rainmeter.exe'
}
$RainmeterRoot = $RainmeterRoot.Trim().Trim('"')
if ([string]::IsNullOrWhiteSpace($RainmeterRoot)) {
    throw 'RainmeterRoot cannot be empty.'
}
$rainmeterExe = Join-Path $RainmeterRoot 'Rainmeter.exe'
if (-not (Test-Path -LiteralPath $rainmeterExe)) {
    throw "Rainmeter.exe not found in '$RainmeterRoot'. Enter the portable install directory that contains Rainmeter.exe."
}
if ($WaitForProcessId -gt 0) {
    try { Wait-Process -Id $WaitForProcessId -Timeout 30 -ErrorAction SilentlyContinue } catch {}
}

$targetHostPaths = @(
    (Join-Path $RainmeterRoot 'Skins\Todo\@Resources\TodoHost.exe'),
    (Join-Path $RainmeterRoot 'Skins\Calendar\@Resources\CalendarHost.exe')
)
foreach ($hostProcess in Get-Process -Name TodoHost,CalendarHost -ErrorAction SilentlyContinue) {
    if ($targetHostPaths -contains $hostProcess.Path) {
        try { $hostProcess.CloseMainWindow() | Out-Null } catch {}
    }
}
Start-Sleep -Milliseconds 800
foreach ($hostProcess in Get-Process -Name TodoHost,CalendarHost -ErrorAction SilentlyContinue) {
    if ($targetHostPaths -contains $hostProcess.Path) {
        try {
            if (-not $hostProcess.HasExited) { $hostProcess.Kill() }
            $hostProcess.WaitForExit(3000)
        } catch {}
    }
}

foreach ($skin in @('Todo', 'Calendar')) {
    $source = Join-Path $sourceSkins $skin
    $target = Join-Path $RainmeterRoot ('Skins\' + $skin)
    New-Item -ItemType Directory -Path $target -Force | Out-Null

    $preserved = @{}
    foreach ($name in @('tasks.json','Generated.inc','calendar-cache.json','calendar-state.json','caldav.secret','translation.secret','paper-sync.secret')) {
        $path = Join-Path $target ('@Resources\' + $name)
        if (Test-Path -LiteralPath $path) { $preserved[$name] = [IO.File]::ReadAllBytes($path) }
    }

    Copy-Item -Path (Join-Path $source '*') -Destination $target -Recurse -Force
    Get-ChildItem -LiteralPath $target -Recurse -File | Unblock-File -ErrorAction SilentlyContinue

    foreach ($name in $preserved.Keys) {
        $destination = Join-Path $target ('@Resources\' + $name)
        New-Item -ItemType Directory -Path (Split-Path $destination -Parent) -Force | Out-Null
        [IO.File]::WriteAllBytes($destination, $preserved[$name])
    }
}

$running = @(Get-Process -Name Rainmeter -ErrorAction SilentlyContinue | Where-Object { $_.Path -eq $rainmeterExe })
if ($running.Count -gt 0) {
    & $rainmeterExe '!Quit'
    Start-Sleep -Milliseconds 1200
    $remaining = @(Get-Process -Name Rainmeter -ErrorAction SilentlyContinue | Where-Object { $_.Path -eq $rainmeterExe })
    foreach ($process in $remaining) {
        try { $process.Kill(); $process.WaitForExit(3000) } catch {}
    }
}
Start-Process -FilePath $rainmeterExe | Out-Null
Start-Sleep -Milliseconds 1200
& $rainmeterExe '!RefreshApp'
if ($Activate) {
    Start-Sleep -Milliseconds 800
    & $rainmeterExe '!ActivateConfig' 'Todo' 'Todo.ini'
    & $rainmeterExe '!ActivateConfig' 'Calendar' 'Calendar.ini'
    Start-Sleep -Milliseconds 800
    & $rainmeterExe '!SetWindowPosition' '100%' '0%' '100%' '0%' 'Todo'
}
Write-Host "Installed skins to $RainmeterRoot\Skins"
