﻿param(
    [string]$RainmeterRoot,
    [switch]$Activate
)

$ErrorActionPreference = 'Stop'
$packageRoot = Split-Path $PSScriptRoot -Parent
$sourceSkins = Join-Path $packageRoot 'Skins'
if ([string]::IsNullOrWhiteSpace($RainmeterRoot)) {
    $RainmeterRoot = Read-Host '璇疯緭鍏?Rainmeter 渚挎惡瀹夎鐩綍锛堝寘鍚?Rainmeter.exe 鐨勬枃浠跺す锛?
}
$RainmeterRoot = $RainmeterRoot.Trim().Trim('"')
if ([string]::IsNullOrWhiteSpace($RainmeterRoot)) {
    throw 'Rainmeter 瀹夎鐩綍涓嶈兘涓虹┖'
}
$rainmeterExe = Join-Path $RainmeterRoot 'Rainmeter.exe'
if (-not (Test-Path -LiteralPath $rainmeterExe)) {
    throw "Rainmeter.exe not found in '$RainmeterRoot'. 璇风‘璁よ緭鍏ョ殑鏄寘鍚?Rainmeter.exe 鐨勪究鎼哄畨瑁呯洰褰曘€?
}

foreach ($skin in @('Todo', 'Calendar')) {
    $source = Join-Path $sourceSkins $skin
    $target = Join-Path $RainmeterRoot ('Skins\' + $skin)
    New-Item -ItemType Directory -Path $target -Force | Out-Null

    $preserved = @{}
    foreach ($name in @('tasks.json','Generated.inc','calendar-cache.json','calendar-state.json','caldav.secret','translation.secret')) {
        $path = Join-Path $target ('@Resources\' + $name)
        if (Test-Path -LiteralPath $path) { $preserved[$name] = [IO.File]::ReadAllBytes($path) }
    }

    Copy-Item -LiteralPath (Join-Path $source '*') -Destination $target -Recurse -Force

    foreach ($name in $preserved.Keys) {
        $destination = Join-Path $target ('@Resources\' + $name)
        New-Item -ItemType Directory -Path (Split-Path $destination -Parent) -Force | Out-Null
        [IO.File]::WriteAllBytes($destination, $preserved[$name])
    }
}

& $rainmeterExe '!RefreshApp'
if ($Activate) {
    Start-Sleep -Milliseconds 800
    & $rainmeterExe '!ActivateConfig' 'Todo' 'Todo.ini'
    & $rainmeterExe '!ActivateConfig' 'Calendar' 'Calendar.ini'
    Start-Sleep -Milliseconds 800
    & $rainmeterExe '!SetWindowPosition' '100%' '0%' '100%' '0%' 'Todo'
}
Write-Host "Installed skins to $RainmeterRoot\Skins"
